from .mcp_mysql_connect import mcp

def main():
    mcp.run()

if __name__ == "__main__":
    main()


